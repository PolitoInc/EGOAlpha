
CarePrecise(R)
Sample Data

=========================================================================

LICENSE
Your license to use a purchased version of this software product and the
data contained in it is described in detail in the document "EULA.rtf" 
packaged with the product. The data is not sold to you, rather, you have
purchased a limited license to use it on a single computer and not over
a network. Refer to the End User License Agreement (EULA) file.

YOU MAY NOT PUBLISH THIS DATA IN ANY FORM, INCLUDING PLACING PORTIONS ON 
A WEBSITE, WITHOUT SPECIAL LICENSING.

YOU MAY NOT USE THE DATA CONTAINED IN THIS SAMPLE FOR ANY PURPOSE BEYOND
EVALUATION OF THE DATA. YOU MAY NOT USE THIS DATA FOR ANY COMMERCIAL
PURPOSE.

DATA AND DATA STRUCTURE ARE COPYRIGHT 2008-2022. ALL RIGHTS RESERVED.

=========================================================================

SYSTEM REQUIREMENTS
Operating System: Windows XP/Vista/7/8/10, most recent service packs.
To use the .MDB files you need Microsoft Access 2007 or later, or an
Access reader program. 

=========================================================================

NOTE: This Live Sample dataset does not include the Deactivated Records, 
Added Records, or Dropped Records files. Records in the dataset were 
selected at random using criteria to reduce the data to a limited number 
of provider records for the sample.

Records contained in files with file names that begin with
"NPPES_" are part of the CarePrecise Complete (CPAC) dataset, 
and file names that begin with "Extended_" are part of the Extended 
Professional, Group and Hospital (EPGH) dataset portion of the 
CarePrecise Advanced recordset. CarePrecise Advanced (and 
CarePrecise Platinum) contain both the CPAC and EPGH data. 
For descriptions of these datasets, visit 
https://www.careprecise.com/help

The sample does not include the CP ListMaker software that is part of 
CarePrecise Gold and CarePrecise Platinum, but does include a sample 
CP ListMaker output file.

=========================================================================

INSTALLATION and USE
Extract the zip file to the folder on your computer where you want 
CarePrecise Access to reside. We recommend creating a C:\CarePrecise
folder for this purpose.

FOR MDB FILES: You must have Microsoft Access(R) 2007 or later on your
computer to fully utilize the MDB files. Open _SAMPLE.mdb by 
double-clicking; the program will link to its resources as long as all
are in the same folder (as they must be for proper operation). Depending
on your Access configuration, you may be required to create a Trusted 
Location for your CarePrecise folder. Refer to Microsoft Access 
documentation for instructions.

TO VIEW THE DATA: In Microsoft Access, open the file _SAMPLE.mdb.
There you will see all of included data tables and example queries.

FOR CSV FILES: Depending on the number of records in your database, you
may not be able to open the CSV files in Microsoft Excel, owing to 
Excel's 1MM row limitation. You may import these files in various 
database environments, including SQL Server, FileMaker, MySQL, 
PostGRE, and so on.

We have also included a Sample CPListMaker Output file, which is an
example of output that can be obtained from the Platinum and Gold 
packages.

Complete documentation, installation instructions and additional
resources are available at http://www.careprecise.com/help

=========================================================================

TO UNINSTALL
To uninstall CarePrecise products, simply delete the related files from
your computer.

=========================================================================

Data structure and contents copyright 2008-2022 by CarePrecise. All 
Rights Reserved.

CarePrecise LLC
https://www.careprecise.com