
CarePrecise(R)
CarePrecise Select(TM) Custom Datasets
CarePrecise Select Plus(TM) Custom Datasets

==================================================

LICENSE
Your license to use this software product and the 
data contained in it is described in detail in the
document "EULA.rtf" packaged with the product
within the CSV and MDB file folders.
The data is not sold to you, rather, you have 
purchased a limited license to use it on a single 
computer and not over a network. Refer to
the End User License Agreement (EULA) file.

YOU MAY NOT PUBLISH THIS DATA IN ANY FORM, 
INCLUDING PLACING PORTIONS ON A WEBSITE, WITHOUT 
SPECIAL LICENSING. Contact sales@careprecise.com 
for special licensing information.

==================================================

SYSTEM REQUIREMENTS
Operating System: Windows XP/Vista/7/8/10, 
most recent service packs. To use the .MDB files 
you need Microsoft Access or an Access reader 
program. 

Memory: Minimum 2GB, 4GB to 8GB recommended for 
broad querying. Hard Drive Space: Dependent on 
size of database. The full database can be 
expected to require as much as 4GB of hard
drive space for storage and substantially more 
space while in use. 

==================================================

INSTALLATION and USE
Extract the zip file to the folder on your 
computer where you want CarePrecise Access to 
reside. 

THE FLAT FILE (Excel file): You must have 
Microsoft Excel 2007 or later installed on your
computer. 

THE "ALLREPORTEDTAXONOMY" FILE:
This file contains the same providers as the Excel
flat file, but providers that have more than one 
taxonomy code (specialty or facility description),
there will be more than one record (row) in the 
file, one for each taxonomy code.

MDB FILES: You must have Microsoft Access 
2003, 2007 or later on your computer to fully 
utilize the MDB files. If you ordered the standard
CarePrecise Select or single state product, open 
NPPES_CORE.mdb. If you ordered the Select Plus
product, open the Extended_CORE.mdb file. The 
program will link to its resources as long as all 
are in the same folder (as they must be for proper 
operation). 

CSV FILES: The CSV files are organized as a 
relational database and are not intended for use 
within Excel. Use FlatFile.xlsx for the limited 
Excel version.

You may also import these files in various 
database environments, including Microsoft Access, 
SQL Server, FileMaker, MySQL, PostGRE, SalesForce,
and so on.

BE SURE to read any other documentation that came 
with your CarePrecise Access, CarePrecise Select,
CP ListMaker, CP Demographics or other products 
from CarePrecise Technology, as many of these 
products are interconnected and operate as a 
unified system.

Complete documentation and additional resources 
are available at http://www.careprecise.com/help

==================================================
HOW TO UPDATE YOUR DATA
Do not make changes in the underlying data tables 
(i.e. tAddresses); rather, keep all of your 
custom data and queries in the table 
NPPES_CORE.mdb. Then when you receive an update 
of the underlying data, you can simply copy the 
new data files (but not the new NPPES_CORE.mdb
file) into the same folder as your old data, 
overwriting the old files.

To obtain an update of the CarePrecise product, 
simply make a new purchase of the product at 
http://www.careprecise.com. 

==================================================

UNINSTALL CarePrecise Access(TM) or CarePrecise 
Select(TM) 
To uninstall CarePrecise products, simply delete 
the related files from your computer.

==================================================

SUPPORT
Complete documentation and additional resources 
are available at http://www.careprecise.com/help

Email support@careprecise.com for support. 
Support is limited according to the terms of your 
purchase. Paid Premium and Advanced Support is
available. For support options, go to:
http://www.careprecise.com/help/support.htm

==================================================


CarePrecise(TM) Technology LLC
http://www.careprecise.com

Data structure and contents copyright 2008, 2009, 
2010, 2011, 2012, 2013, 2014, 2015, 2016, 2017, 
2018, 2019, 2020 by CarePrecise. 
All Rights Reserved.
